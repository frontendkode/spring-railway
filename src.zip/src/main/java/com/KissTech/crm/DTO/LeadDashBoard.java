package com.KissTech.crm.DTO;

import lombok.Data;

@Data
public class LeadDashBoard {
    private String totalLeads;
    private String totalVisit;
    private String convert;
    private String futureInterest;
    private String conversionRate;

}
