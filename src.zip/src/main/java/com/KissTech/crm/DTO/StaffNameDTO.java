package com.KissTech.crm.DTO;

import lombok.Data;

import java.util.UUID;

@Data
public class StaffNameDTO {
    private String staffName;
    private UUID id;
}
