package com.KissTech.crm.DTO;

import lombok.Data;

@Data
public class TaskNotificationDTO {

    private String staffName;
private String dueDate;
private String priority;
private String taskTitle;
private String status;
}
