package com.KissTech.crm.DTO;

import lombok.Data;

@Data
public class StudentDashBoardDTO {
    private String fullName;
    private String course;
}
