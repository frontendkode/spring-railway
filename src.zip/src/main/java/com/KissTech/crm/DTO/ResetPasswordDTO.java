package com.KissTech.crm.DTO;

import lombok.Data;

@Data
public class ResetPasswordDTO {
   
	private String password;
	
	private String token;
	
}
