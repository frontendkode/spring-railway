package com.KissTech.crm.DTO;

import jdk.dynalink.linker.LinkerServices;
import lombok.Data;

import java.util.List;

@Data
public class LeadDashBoardDTO {
    private String fullName;
    private String stage;
    private String source;

}
