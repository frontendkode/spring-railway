package com.KissTech.crm.DTO;

import lombok.Data;

@Data
public class LoginRequestDTO {


    private String encData;
    private String username;
    private String password;


}
