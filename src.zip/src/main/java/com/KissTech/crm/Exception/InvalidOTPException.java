package com.KissTech.crm.Exception;

public class InvalidOTPException extends RuntimeException{
	public InvalidOTPException(String message) {
		super(message);
	}
}
