package com.KissTech.crm.createDTO;

import lombok.Data;

@Data
public class CreateDueDayDTO {

    private String dueNo;
    private String dueAmt;
    private String dueDate;
    private String status;
    private String createAt;

    private String paymentType;
    private String paymentDate;
}
