package com.KissTech.crm.createDTO;

import lombok.Data;

@Data
public class CreateAttendanceDTO {


    private String date;
    private String day;
    private String attend;
    private String createAt;
}
