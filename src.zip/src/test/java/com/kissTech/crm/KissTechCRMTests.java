package com.kissTech.crm;

import com.KissTech.crm.KissTechCRM;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest()  // explicitly specify main class
public class KissTechCRMTests {

	@Test
	void contextLoads() {
		// simple test to check if Spring context loads
	}
}
